<template>
	<div class="help">
		<img src="../../assets/help.png" alt="">
	</div>
</template>
<script>
	export default{}
</script>
<style>
	.help{
		display: flex;
	}
	.help img{
		margin: auto;
	}
</style>